package com.model;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class Scraper {

	public static void main(String[] args) throws Exception {

		final Document doc = Jsoup.connect("http://www.imdb.com/chart/top").get();
		int count = 0;
		for (Element e : doc.select("tbody.lister-list tr")) {
			count++;
			final String movieTitle = e.select(".titleColumn a").text();
			final String movieRating = e.select(".imdbRating").text();

			System.out.println(count + " -|| " + movieRating + " || " + movieTitle);

		}
	}
}
